export const imgLoadMixin={
    data(){
        return {
            imgCount:1,
        }
    },
}