/**
 * --scrollbar-bgcolor是滚动条背景颜色
 * --scrollbar-color 滚动条小球颜色
 */
export default {
    ['--scrollbar-track-color']: '#f1f1f1',
    ['--scrollbar-thumb-color']: '#cdcdcd',
}