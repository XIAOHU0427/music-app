export default {
    ['--scrollbar-track-color']: '#16181c',
    ['--scrollbar-thumb-color']: '#4f4f4f',
}