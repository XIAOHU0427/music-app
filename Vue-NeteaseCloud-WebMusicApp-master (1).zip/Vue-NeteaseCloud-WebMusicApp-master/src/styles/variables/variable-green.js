export default {
    ['--scrollbar-track-color']: '#f1f1f1',
    ['--scrollbar-thumb-color']: '#cdcdcd',
}