<template>
  <div class="empty">数据为空~~</div>
</template>
<script>
export default {
  name: "empty",
};
</script>
<style scoped>
.empty {
  padding: 10px 0px;
}
</style>