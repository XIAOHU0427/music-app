### 网络请求说明文档

#### discover 用于个性请求页面----对应：individuation

#### detail 用于歌单详情页面----对应：list-detail

#### music-list 用于所有歌单页面----对应：music-list

#### artist 用于歌手页面----对应：artist