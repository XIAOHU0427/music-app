## views 说明

#### artist-detail           歌手详情页面

#### artist-list             所有歌手分类页面

#### individuation           个性推荐页面

#### list-detail             歌单详情页面

#### music-list              所有歌单分类页面

#### rank-list               排行榜页面

#### mv                      所有MV、MV播放页面
> mv-category                所有MV的分类页面
>mv-detail                   MV详情、播放页面
>mv                          最新MV、推荐MV、MV排行，可以跳转到mv-category页面