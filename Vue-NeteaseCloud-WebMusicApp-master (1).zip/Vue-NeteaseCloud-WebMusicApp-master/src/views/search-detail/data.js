export const menuList=[
    {link:'songs',value: 1 ,content:'单曲'},
    {link:'artist',value:100,content:'歌手'},
    {link:'playlist',value:1000,content:'歌单'},
    {link:'album',value:10,content:'专辑'},
    {link:'mv',value: 1004,content:'MV'},
]